package com.mexpedition.mexpedition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MexpeditionApplicationTests {

	@Test
	void contextLoads() {
	}

}
